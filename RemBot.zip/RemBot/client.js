const Discord   = require(`discord.js`);
const fs        = require(`fs`),
    path        = require(`path`);
const botInfo   = require(`./botinfo.json`);
const remtoken     = botInfo.remtoken;
const ramtoken     = botInfo.ramtoken;
const prefix    = botInfo.prefix;
const client    = new Discord.Client({autoReconnect:true});
const ramclient    = new Discord.Client({autoReconnect:true});
const apiai = require(`apiai`);
const app = apiai("734f92e6f3d84aecb62e6f18ae0a0691");

var magicArray = [`It is certain`, `It is decidedly so`, `Without a doubt`, `Yes definitely` ,`You may rely on it`,`As I see it, yes`,`Most likely`,`Outlook good`,`Yes`,`Signs point to yes`,`Reply hazy try again`,`Ask again later`,`Better not tell you now`,`Cannot predict now`,`Concentrate and ask again`,`Don't count on it`,`My reply is no`,`My sources say no`,`Outlook not so good`,`Very doubtful`];

var isTraining = false;
var isLevi = true;
var isPres = false;
var planDay = "--";
var planDate = "--";
var planTime = "-";
var planTimo = "--";
var setupAuthorID = `-`;
var stepR = 0;
var embed = new Discord.RichEmbed();

function reset() {
    isTraining = false;
    isLevi = true;
    isPres = false;
    planDay = "-";
    planTime = "-";
    setupAuthorID = `-`;
    stepR = 0;
}

ramclient.on(`message`, async message =>{
    if (stepR != 0) return;
    if (message.channel.type == "dm") return;


    if (message.content.toLowerCase().includes(`ram set status to playing`) && message.author.id == `211376467114852352`) {
        ramclient.user.setActivity(message.content.slice(26, message.content.length));
        message.channel.send(`Setting Status To Playing ${message.content.slice(26, message.content.length)}`);
        return;
    }
    if (cleanCode(message.content.toLowerCase()) == `ramram` || cleanCode(message.content.toLowerCase()) == `ramuramu`){
        if (message.author.id != `145399497034301441`) return message.channel.send(`Rem Rem, this person is talking to me.`);
        return message.channel.send(`${message.author.username} ${message.author.username}`);
    }

    if (cleanCode(message.content.toLowerCase()) == `iloveyouram` || cleanCode(message.content.toLowerCase()) == `iloveyouram`){
        if (message.author.id != `145399497034301441`) return message.channel.send(`I'm sorry, I don't love you.`);
        return message.channel.send(`I love you too.`);
    }
});

ramclient.on('ready', async() => {
    ramclient.user.setUsername("Ram");
    ramclient.user.setStatus(`Online`);
    ramclient.user.setActivity(`with Rem`);
    console.log(ramclient.user.username + ' is ready');
});

client.on("guildMemberAdd", function(member){
    let role = member.guild.roles.find(`name`, "Training");
    member.addRole(role.id);

    if (!member.guild.roles.find("name", "Darc's Only Friends")) {
        //client.channels.get('412801312732741641').send(`If we can't be Darc's friend then me and sister are leaving. Goodbye.`);
        //client.disconnect();
    }

    return;
});

client.on("disconnected", function () {
    console.log("They have failed us Darc.");
    process.exit(0); 
});

client.on(`message`, async message => {
    let messageArray = message.content.split(" ");
    let command = messageArray[0].toLowerCase();
    let args = messageArray.slice(1);

    if (command == `${prefix}lonehelp`) {
        embed = new Discord.RichEmbed()
            .setColor("#87ceeb")
            .setTitle(`Lone Raid Schedule Bot Help`)
            .addField(`${prefix}lonehelp`, `Gives you this message\n_ _`)
            .addField(`${prefix}setup raid`, `Starts a raid planning walkthrough\n_ _`)
            .addField(`${prefix}list [day of week]`, `Numbers a list of raids for [day of week]\n_ _`)
            .addField(`${prefix}list [day of week] [# in list]`, `Lists all joined players in the selected raid\n_ _`)
            .addField(`${prefix}leave [day of week] [# in list]`, `Leaves selected raid, you cannot leave if you are leader\n_ _`)
            .addField(`${prefix}join [day of week] [# in list]`, `Joins an open raid, if can\n_ _`)
            .addField(`${prefix}setleader [day of week] [# in list] [@new leader]`, `If leader, sets [@new leader], if in raid, to the new leader\n_ _`)
            .addField(`${prefix}betasetup`,`Beta raid setup menu - tutorial in menu`);
        message.author.send(embed);
    }

    if (message.channel.type == "dm") {
        console.log(message.author.username + ": " + message.content);
        return;
    }

    //if (!message.guild.roles.find("name", "Darc's Only Friends")) {
    //    if (message.author.bot) return;
    //    client.channels.get('412801312732741641').send(`If we can't be Darc's friend then me and sister are leaving. Goodbye.`);
    //    client.disconnect();
    //}

    if (message.content.toLowerCase().includes(`rem set status to playing`) && message.author.id == `211376467114852352`) {
        client.user.setActivity(message.content.slice(26, message.content.length));
        message.channel.send(`Setting Status To Playing ${message.content.slice(26, message.content.length)}`);
        return;
    }

    if (command == `${prefix}lenny`) {
        message.delete();
        message.channel.send(`( ͡° ͜ʖ ͡°)`);
        return;
    }

    if (command == `${prefix}mfw`) {
        message.delete();
        message.channel.send(`(✿◠‿◠)`);
        return;
    }

    if (command == `${prefix}m8` || command == `${prefix}magic8`) {
        if(cleanCode(message.content.slice(7, message.content.length).toLowerCase()).includes(`ihavesomethingtoeat`) ) {
            return message.channel.send(`No`);
        }
        var rnd = Math.floor(Math.random() * 20);
        return message.channel.send(magicArray[rnd]);
    }

    if (command == `${prefix}magic`) {
        if(cleanCode(message.content.slice(7, message.content.length).toLowerCase()).includes(`ihavesomethingtoeat`)) {
            return message.channel.send(`No`);
        }
        var rnd = Math.floor(Math.random() * 20);
        return message.channel.send(magicArray[rnd]);
    }

    //--Rem Chat Bot--
    
    if (message.channel.id == '427934230211723274'){
        if (command == `${prefix}list`){ }
        else if (command == `${prefix}join`){ }
        else if (command == `${prefix}leave`){ }
        else if (command == `${prefix}leave`){ }
        else if (command == `${prefix}setleader`){ }
        else if (command == `${prefix}betasetup`) { } 
        else if (command == `?purge`) { }
        else {
            botResponse(message);
        }
    }

    if (message.author.bot) return;
    //--Rem Raid Scheduler--

    if (message.channel.id == `428442803123519490`) {
        if (command == `${prefix}fr`) {
            if (args[0] == `1488`){
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setDescription(`Setup Canceled.`)
                message.channel.send(embed);
                reset();
            }
            return;
        }
        if (command == `${prefix}setup` && stepR == 0) {
            if (args[0] == `raid`) {
                reset();
                setupAuthorID = message.author.id;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`Training?`)
                    .setDescription(`[1]Yes\n[2]No`)
                    .setFooter(`[0]Cancel`);
                message.channel.send(embed);
                return;
            }
        }
        if (stepR == 3 && setupAuthorID == message.author.id) {
            var days = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
            
            embed = new Discord.RichEmbed()
                .setColor("#87ceeb");
            
            switch (message.content) {
                case '1':
                    break;
                case '2':
                    break;
                case '3':
                    break;
                case '4':
                    break;
                case '5':
                    break;
                case '6':
                    break;
                case '7':
                    break;
                default:
                    embed = embed
                        .setDescription(`Not a valid day.`)
                        .setFooter(`[0]Cancel`);
                    return message.channel.send(embed);
            }
            planDay = days[parseInt(message.content - 1)];
            planDate = planDay
            var files = fs.readdirSync(`./raids/${fU(planDay.toLowerCase())}/`);
            if (files.length >= 4) {
                embed = embed
                    .setDescription(`Too many raids scheduled that day.`)
                    .setFooter(`[0]Cancel`);
                return message.channel.send(embed);
            }

            embed = embed
                .setTitle(`What Time?`)
                .setDescription(`Format must be (est, pst, cst, mst, bst, cest, eest, acst, aest, awst).`)
                .setFooter(`[0]Cancel`);
            stepR++;
            message.channel.send(embed);
            return;
        }
        if (command == `1` && setupAuthorID == message.author.id) {
            if (stepR == 0) {
                isTraining = true;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`Which Raid?`)
                    .setDescription(`[1]Levithan\n[2]Eater of Worlds`)
                    .setFooter(`[0]Cancel`);
                    
                message.channel.send(embed);
            }
            if (stepR == 1) {
                isLevi = true;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`Which Difficulty?`)
                    .setDescription(`[1]Normal\n[2]Prestige`)
                    .setFooter(`[0]Cancel`);
                message.channel.send(embed);
            }
            if (stepR == 2) {
                isPres = false;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`What Day?`)
                    .setDescription(`[1]Sunday\n[2]Monday\n[3]Tuesday\n[4]Wednesday\n[5]Thursday\n[6]Friday\n[7]Saturday`)
                    .setFooter(`[0]Cancel`);
                message.channel.send(embed);
            }
            stepR++;
            return;
        }
        if (command == `2` && setupAuthorID == message.author.id) {
            if (stepR == 0) {
                isTraining = false;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`Which Raid?`)
                    .setDescription(`[1]Levithan\n[2]Eater of Worlds`)
                    .setFooter(`[0]Cancel`);
                message.channel.send(embed);
            }
            if (stepR == 1) {
                isLevi = false;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`Which Difficulty?`)
                    .setDescription(`[1]Normal\n[2]Prestige`)
                    .setFooter(`[0]Cancel`);
                message.channel.send(embed);
            }
            if (stepR == 2) {
                isPres = true;
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`What Day?`)
                    .setDescription(`[1]Sunday\n[2]Monday\n[3]Tuesday\n[4]Wednesday\n[5]Thursday\n[6]Friday\n[7]Saturday`)
                    .setFooter(`[0]Cancel`);
                message.channel.send(embed);
            }
            stepR++;
            return;
        }
        if (command == `0` && setupAuthorID == message.author.id) {
            embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setDescription(`Setup Canceled.`)
            message.channel.send(embed);
            reset();
        }
        if (stepR == 4 && setupAuthorID == message.author.id) {
            embed = new Discord.RichEmbed()
                    .setColor("#87ceeb");
            planTime = message.content.toLowerCase();
            if (!planTime.includes('est') && !planTime.includes('pst')) {
                if (!planTime.includes('cst') && !planTime.includes('mst')) {
                    if (!planTime.includes('bst') && !planTime.includes('cest')) {
                        if (!planTime.includes(`eest`) && !planTime.includes('acst')) {
                            if (!planTime.includes(`aest`) && !planTime.includes('awst')) {
                                embed = embed
                                    .setTitle(`Please set timezone.`)
                                    .setDescription(`est, pst, cst, mst, bst, cest, eest, acst, aest, awst`)
                                    .setFooter(`[0]Cancel`);
                                return message.channel.send(embed);
                            }
                        }
                    }
                }
            }
            planTimo = planTime;
            stepR++;
            embed = embed
                .setTitle(`What is The Raids Name?`)
                .setDescription(`Give it a title.`)
                .setFooter(`[0]Cancel`);
            message.channel.send(embed);
            return;
        }
        if (stepR == 5 && setupAuthorID == message.author.id) {
            embed = new Discord.RichEmbed()
                    .setColor("#87ceeb");

            planDay = planDate;
            planTime = planTimo;
            fs.open(`./raids/${fU(planDay)}/${message.content}.txt`, 'wx', (err, fd) => {
                if (err) {
                    if (err.code == `EEXIST`) {
                        embed = embed
                            .setDescription(`Invalid Name - Name already taken`);
                        message.channel.send(embed)
                        return;
                    }
                } else {
                    fs.writeFile(`./raids/${fU(planDay)}/${message.content}.txt`,`Training=${isTraining}\nLevithan=${isLevi}\nPrestige=${isPres}\n${fU(planDay)}\n${planTime}\n${message.author.id}`, finished);
                    embed = embed
                        .setDescription(`Thank You For Your Time. The ${message.content} has been setup on ${fU(planDay)}.`)
                    message.channel.send(embed);
                    reset();
                    return;
                } 
            });
            return;
        }
        if (command == `${prefix}bsetup`){
            embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setFooter(`Type !lonehelp for useful commands`);

            if (!args[0]) {
                embed = embed
                    .setDescription(`Invalid Raid - Error at [Training]`);
                message.channel.send(embed);
                return;
            } else if (!args[1]) {
                embed = embed
                    .setDescription(`Invalid Raid - Error at [Raid]`);
                message.channel.send(embed);
                return;
            } else if (!args[2]) {
                embed = embed
                    .setDescription(`Invalid Raid - Error at [Difficulty]`);
                message.channel.send(embed);
                return;
            } else if (!args[3]) {
                embed = embed
                    .setDescription(`Invalid Raid - Error at [Day]`);
                message.channel.send(embed);
                return;
            } else if (!args[4] && !args[5]) {
                embed = embed
                    .setDescription(`Invalid Raid - Error at [Time]`);
                message.channel.send(embed);
                return;
            } else if (!args[6]) {
                embed = embed
                    .setDescription(`Invalid Raid - Error at [Title]`);
                message.channel.send(embed);
                return;
            } else {
                if (args[0] < 0 || args[0] > 2) {
                    embed = embed
                        .setDescription(`Invalid Raid - Error at [Training]`);
                    message.channel.send(embed);
                    return;
                } else if (args[1] < 0 || args[1] > 2) {
                    embed = embed
                        .setDescription(`Invalid Raid - Error at [Raid]`);
                    message.channel.send(embed);
                    return;
                } else if (args[2] < 0 || args[2] > 2) {
                    embed = embed
                        .setDescription(`Invalid Raid - Error at [Difficulty]`);
                    message.channel.send(embed);
                    return;
                } else if (args[3] < 0 || args[3] > 7) {
                    embed = embed
                        .setDescription(`Invalid Raid - Error at [Day]`);
                    message.channel.send(embed);
                    return;
                } else {
                    

                    var days = [`Sunday`,`Monday`,`Tuesday`,`Wednesday`,`Thursday`,`Friday`,`Saturday`];
                    var namePos = 0;       
                    var isTraining;
                    var isLevi;
                    var isPres;

                    for (var x = 0; x < 7; x++) {
                        namePos += args[x].length;
                    }
                    namePos += 8;
                    var nameRaid = message.content.slice(namePos, message.content.length); 

                    if (args[0] == `1`) { isTraining = true; } else { isTraining = false; }
                    if (args[1] == `1`) { isLevi = true; } else { isLevi = false; }  
                    if (args[2] == `2`) { isPres = true; } else { isPres = false; }
                    var planDay = days[args[3] - 1];
                    var planTime = args[4] + ` ` + args[5];
                    planTime = planTime.toLowerCase();

                    if (!planTime.includes('est') && !planTime.includes('pst')) {
                        if (!planTime.includes('cst') && !planTime.includes('mst')) {
                            if (!planTime.includes('bst') && !planTime.includes('cest')) {
                                if (!planTime.includes(`eest`) && !planTime.includes('acst')) {
                                    if (!planTime.includes(`aest`) && !planTime.includes('awst')) {
                                        embed = embed
                                            .setTitle(`Please set timezone.`)
                                            .setDescription(`EST, PST, CST, MST, BST, CEST, EEST, ACST, AEST, AWST`)
                                        return message.channel.send(embed);
                                    }
                                }
                            }
                        }
                    }

                    var fileRaid = `./raids/${planDay}/${nameRaid}.txt`;
                    var contentsRaid = `Training=${isTraining}\nLevithan=${isLevi}\nPrestige=${isPres}\n${fU(planDay.toLowerCase())}\n${planTime}\n${message.author.id}`;
                    
                    fs.open(fileRaid, 'wx', (err, fd) => {
                        if (err) {
                            if (err.code == `EEXIST`) {
                                embed = embed
                                    .setDescription(`Invalid Name - Name already taken`);
                                message.channel.send(embed)
                                return;
                            }
                        } else {
                            embed = embed
                                .setDescription(`Thank You For Your Time. The ${nameRaid} has been setup on ${planDay} @${planTime}.`);
                            fs.writeFile(fileRaid, contentsRaid, finished);
                            message.channel.send(embed);
                            return;
                        } 
                    });
                }
            }
            return;
        }
        if (command == `${prefix}betasetup`) {
                embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setTitle(`Setup Raid.`)
                .setDescription(`Use !bsetup to make a raid in a single line`)
                .addField(`1. Training`,`[1]Yes\n[2]No\n_ _`, true)
                .addField(`2. Raid`,`[1]Leviathan\n[2]Eater of Worlds`, true)
                .addField(`3. Difficulty`,`[1]Normal\n[2]Prestige`, true)
                .addField(`4. Day`,`[1]Sunday\n[2]Monday\n[3]Tuesday\n[4]Wednesday\n[5]Thursday\n[6]Friday\n[7]Saturday\n_ _`, true)
                .addField(`5. Time - Timezone must be one of the following`,`\nEST, PST, CST, MST, BST, CEST, EEST, ACST, AEST, AWST\n_ _`, true)
                .addField(`6. Title`,`Give it a title.\n_ _`, true)
                .addField(`Example`, `!bsetup 2 1 2 4 6:30pm EST Example Raid\n_ _`)
                .addField(`Dont do`,`:x:6:30 pm\n:white_check_mark:6:30pm`)
                .setFooter(`Type !lonehelp for useful commands`);
            betasetupAuthorID = message.author.id;
            message.channel.send(embed);
            return;
        }

        if (command == `${prefix}list`){}
        else if (command == `${prefix}join`){}
        else if (command == `${prefix}leave`){}
        else if (command == `${prefix}leave`){}
        else if (command == `${prefix}setleader`){}
        else if (command == `${prefix}betasetup`) {} 
        else if (command == `?purge`) {}
        else {
            message.delete();
            return;
        }
    }
    
    //--Rem Commands--
    if (command == `${prefix}list`) {
        embed = new Discord.RichEmbed();
        if (!args[0]) args[0] = `all`;
        
        switch (args[0].toLowerCase()) {
            case "monday":
                break;
            case "tuesday":
                break;
            case "wednesday":
                break;
            case "thursday":
                break;
            case "friday":
                break;
            case "saturday":
                break;
            case "sunday":
                break;
            case "all":
                break;
            default:
                return message.channel.send(`Not a valid day`);
        }

        if (args[0].toLowerCase() == `all`) {
            embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setTitle(`All Raids`);
            listall();
            return message.channel.send(embed);
        } else if (args[1] > 0) {
            var files = fs.readdirSync(`./raids/${args[0]}`);
            if (files.length >= args[1]) {
                embed = new Discord.RichEmbed()
                    .setColor("#87ceeb")
                    .setTitle(`${fU(args[0].toLowerCase())} Raids`);
                list2(`./raids/${args[0]}`, args[1]);
            }
            else {
                embed = embed
                    .setTitle(`Not a valid raid.`);
            }
        } else {
            embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setTitle(`${fU(args[0].toLowerCase())} Raids`);
            list(`./raids/${args[0]}`);
        }
        
        embed = embed
            .setFooter(`Type !lonehelp for useful commands`);
        return message.channel.send(embed);
    }
    if (command == `${prefix}join`) {
        embed = new Discord.RichEmbed();
        if (!args[1]) {
            embed = embed
                .setColor("#87ceeb")
                .setDescription(`No raid selected.`)
                .setFooter(`Type !lonehelp for useful commands`);
            return message.channel.send(embed);
        }
        switch (args[0].toLowerCase()) {
            case "monday":
                break;
            case "tuesday":
                break;
            case "wednesday":
                break;
            case "thursday":
                break;
            case "friday":
                break;
            case "saturday":
                break;
            case "sunday":
                break;
            default:
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Not a valid day.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
        }
        var files = fs.readdirSync(`./raids/${args[0]}`);
        if (files.length < args[1]) {
            embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Not a valid raid.`)
                    .setFooter(`Type !lonehelp for useful commands`);
            return message.channel.send(embed);
        } else {
            if (getPlayers(args[1], `./raids/${args[0]}`).includes(`Invalid`)) {
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Raid doesn't exist.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
            } else if (getPlayers(args[1], `./raids/${args[0]}`).includes(message.author.id)) {
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`You've already joined that raid.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
            } else if (getPlayers(args[1], `./raids/${args[0]}`).includes(`Full`)) {
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Raid is Full.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
            } else {
                var files = fs.readdirSync(`./raids/${args[0]}`);
                fs.appendFile(`./raids/${args[0]}/${files[args[1] - 1]}`, `\n${message.author.id}`, finished);
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Successfully Joined.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
            }
        }
        
        
    }
    if (command == `${prefix}leave`) {
        embed = new Discord.RichEmbed()
            .setColor("#87ceeb");
        if (!args[1]) {
            embed = embed
                .setColor("#87ceeb")
                .setDescription(`No raid selected.`)
                .setFooter(`Type !lonehelp for useful commands`);
            message.channel.send(embed);
            return ;
        }
        switch (args[0].toLowerCase()) {
            case "monday":
                break;
            case "tuesday":
                break;
            case "wednesday":
                break;
            case "thursday":
                break;
            case "friday":
                break;
            case "saturday":
                break;
            case "sunday":
                break;
            default:
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Not a valid day`)
                    .setFooter(`Type !lonehelp for useful commands`);
                message.channel.send(embed);
                return;
        }
        var files = fs.readdirSync(`./raids/${args[0]}`);
        if (files.length >= args[1]) {
            var nex = true;
            get_line(`./raids/${args[0]}/${files[args[1] - 1]}`, 6, function(line){
                if (line == `Open`) {
                    removePlayer(args[1], `./raids/${args[0]}`, message.author.id);
                    embed = embed
                        .setColor("#87ceeb")
                        .setDescription(`Successfully Left.`)
                        .setFooter(`Type !lonehelp for useful commands`);
                    message.channel.send(embed);
                    nex = false;
                    return;
                }
            });
            if (nex) {
                get_line(`./raids/${args[0]}/${files[args[1] - 1]}`, 5, function(line){
                    if (line == message.author.id) {
                        embed = embed
                            .setColor("#87ceeb")
                            .setDescription(`You're Leader you cannot leave, please change the leader before leaving.`)
                            .setFooter(`Type !lonehelp for useful commands`);
                        message.channel.send(embed);
                        return;
                    }
                    else {
                        if (!getPlayers(args[1], `./raids/${args[0]}`).includes(message.author.id)) {
                            embed = embed
                                .setColor("#87ceeb")
                                .setDescription(`You're not in that raid`)
                                .setFooter(`Type !lonehelp for useful commands`);
                            message.channel.send(embed);
                            return;
                        } else {
                            removePlayer(args[1], `./raids/${args[0]}`, message.author.id);
                            embed = embed
                                .setColor("#87ceeb")
                                .setDescription(`Successfully Left.`)
                                .setFooter(`Type !lonehelp for useful commands`);
                            message.channel.send(embed);
                            return;
                        }
                    }
                });
            }
        } else {
            embed = embed
                .setColor("#87ceeb")
                .setDescription(`Not a valid raid.`)
                .setFooter(`Type !lonehelp for useful commands`);
            message.channel.send(embed);
            return;
        }   
    }
    if (command == `${prefix}setleader`) {
        embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setTitle(`Set Leader`);
        let newLeader = message.mentions.members.first();
        if (!newLeader){
            embed = embed
                .setDescription(`No user selected.`)
            message.channel.send(embed);
            return;
        }
        
        if (newLeader.id == message.author.id) {
            embed = embed
                .setDescription(`You cannot make yourself leader.`)
            message.channel.send(embed);
            return;
        }
        
        setLeader(args[1], `./raids/${args[0]}`, message.author.id, newLeader.id);
        message.channel.send(embed);
        return;
    }
    if (command == `${prefix}delete`) {
        embed = new Discord.RichEmbed()
                .setColor("#87ceeb")
                .setTitle(`Delete Raid`);

        switch (args[0].toLowerCase()) {
            case "monday":
                break;
            case "tuesday":
                break;
            case "wednesday":
                break;
            case "thursday":
                break;
            case "friday":
                break;
            case "saturday":
                break;
            case "sunday":
                break;
            default:
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Not a valid day.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
            }
            var files = fs.readdirSync(args[0]);
            if (args[1] > files.length) {
                embed = embed
                    .setColor("#87ceeb")
                    .setDescription(`Not a valid raid.`)
                    .setFooter(`Type !lonehelp for useful commands`);
                return message.channel.send(embed);
            } else {
                get_line(`${args[0]}/${files[x]}`, 5, function(line){
                    if (line != message.author.id) {
                        embed = embed
                            .setColor("#87ceeb")
                            .setDescription(`You're not the leader.`)
                            .setFooter(`Type !lonehelp for useful commands`);
                        return message.channel.send(embed);
                    } else {
                        fs.unlink(`${args[0]}/${files[args[1]]}`,finished);
                        embed = embed
                            .setColor("#87ceeb")
                            .setDescription(`Successfully Deleted.`)
                            .setFooter(`Type !lonehelp for useful commands`);
                        return message.channel.send(embed);
                    }
                });
            }
                    
        message.channel.send(embed);
        return;
    }
});

client.on('ready', async() => {
    client.user.setUsername("Rem");
    client.user.setStatus(`Online`);
    client.user.setActivity(`with Ram`);
    console.log(client.user.username + ' is ready');
});

client.login(remtoken);
ramclient.login(ramtoken);



function cleanCode(c) {
    return c.replace(/[^A-Za-z0-9_]/g,"");
}
function fU(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}
function finished(err){
}
function list(dir) {
    var files = fs.readdirSync(dir);
    var counter = 1;

    for (var x in files) {
        var lis = ``;
        var t = ``;
        get_line(`${dir}/${files[x]}`, 2, function(line){
            if (line.includes(`Levithan=false`)) {
                t += `EoW `;
            } else {
                t += `Levithan `;
            }
        });
        get_line(`${dir}/${files[x]}`, 2, function(line){
            if (line.includes(`=true`)) {
                t += `Prestige `;
            }
        });
        get_line(`${dir}/${files[x]}`, 0, function(line){
            if (line.includes(`=true`)) {
                t += `Training Raid on `;
            } else {
                t += `Raid on `;
            }
        });
        get_line(`${dir}/${files[x]}`, 3, function(line){
            t += line + ` @`;
        });
        get_line(`${dir}/${files[x]}`, 4, function(line){
            t += line;
        });
        get_line(`${dir}/${files[x]}`, 5, function(line){
            if (line != `Open` && line != ``) { 
                lis += `\n_ _ _ _ _ _ [Leader]<@${line}>`; 
            }
        });
        embed = embed
                .addField(`[${counter}] ${files[x].slice(0, -4)} - ${t}`, lis);
        counter++;
    }
    if (counter == 1) {
        embed = embed
            .addField(`No Raids`, `There are no raids planned.`);
    }
}
function list2(dir, x) {
    var files = fs.readdirSync(dir);
    var lis = ``;
    var t = ``;
    x--;
    var counter = 1;

    for (var y in files) { 
        if (y == x) {
            break;
        }
        else{
            counter++;
        }
    }

    get_line(`${dir}/${files[x]}`, 2, function(line){
        if (line.includes(`Levithan=false`)) {
            t += `EoW `;
        } else {
            t += `Levithan `;
        }
    });
    get_line(`${dir}/${files[x]}`, 2, function(line){
        if (line.includes(`=true`)) {
            t += `Prestige `;
        }
    });
    get_line(`${dir}/${files[x]}`, 0, function(line){
        if (line.includes(`=true`)) {
            t += `Training Raid @`;
        } else {
            t += `Raid @`;
         }
    });
    get_line(`${dir}/${files[x]}`, 4, function(line){
        t += line;
    });
    for (var y = 5; y < 11; y++){
        get_line(`${dir}/${files[x]}`, y, function(line){
            if (y == 5) {
                if (line != `Open` && line != ``) { 
                    lis += `\n${y - 4}. <@${line}> [Leader]`; 
                }
            } else {
                if (line != `Open` && line != ``) { lis += `\n${y - 4}. <@${line}>`; }
                else { lis += `\n${y - 4}. Open`; }
               }            
        });
    }
    embed = embed
            .setDescription(`Raid #${counter}`)
            .addField(`${files[x].slice(0, -4)} - ${t}`, lis);
}
function listall() {
    var sunday = fs.readdirSync(`./raids/sunday`);
    var monday = fs.readdirSync(`./raids/monday`);
    var tuesday = fs.readdirSync(`./raids/tuesday`);
    var wednesday = fs.readdirSync(`./raids/wednesday`);
    var thursday = fs.readdirSync(`./raids/thursday`);
    var friday = fs.readdirSync(`./raids/friday`);
    var saturday = fs.readdirSync(`./raids/saturday`);
    embed = embed
        .addField(`Sunday`, `${sunday.length} raids planned\n_ _`, true)
        .addField(`Monday`, `${monday.length} raids planned\n_ _`, true)
        .addField(`Tuesday`, `${tuesday.length} raids planned\n_ _`, true)
        .addField(`Wednesday`, `${wednesday.length} raids planned\n_ _`, true)
        .addField(`Thursday`, `${thursday.length} raids planned\n_ _`, true)
        .addField(`Friday`, `${friday.length} raids planned\n_ _`, true)
        .addField(`Saturday`, `${saturday.length} raids planned`, true);
}
function getPlayers(x, dir) {
    var files = fs.readdirSync(`${dir}`);
    if (files.length < x){ 
        return `Invalid`;
    }
    else {
        var lis = ``;
        x--;
        for (var y = 5; y < 10; y++){
            get_line(`${dir}/${files[x]}`, y, function(line){
                lis += `${line}\n`;
            }); 
        }
        get_line(`${dir}/${files[x]}`, 10, function(line){
            if (line != `Open`) {
                return `Full`;
            }
        });
        return lis;
    }
    
}
function removePlayer(x, dir, playerID) {
    var files = fs.readdirSync(`${dir}`);
    if (files == 0){ return; }
    var lis = ``;
    var counter = 0;
    x--;
    get_line(`${dir}/${files[x]}`, 0, function(line){
        lis += `${line}`;
    });
    for (var y = 1; y < 10; y++){
        get_line(`${dir}/${files[x]}`, y, function(line){
            if (line != `Open` && line != playerID) {
                lis += `\n${line}`;
            }
            if (line == `Open` || line == playerID) {
                counter++;
            }
        }); 
    }
    if (counter == 5) {
        fs.unlink(`${dir}/${files[x]}`,finished);
    } else {
        fs.writeFile(`${dir}/${files[x]}`, lis, finished);
    }
}
function setLeader(x, dir, playerID, newPlayerID) {
    var files = fs.readdirSync(`${dir}`);
    if (files == 0){ 
        embed = embed
            .setDescription(`Not a valid raid day.`);
        return;
    }
    if (!`${dir}/${!files[x]}`) {
        embed = embed
            .setDescription(`Not a valid raid.`);
        return;
    }
    var lis = ``;
    x--;
    var temp = null;
    var succ = true;
    for (var y = 1; y < 10; y++){
        get_line(`${dir}/${files[x]}`, y, function(line){
            if (line == newPlayerID) {
                temp = newPlayerID;
            }
        });
    }
    if (temp == null) {
        embed = embed
            .setDescription(`User is not in that raid.`);
        return;
    }
    get_line(`${dir}/${files[x]}`, 0, function(line){
        lis += `${line}`;
    });


    for (var y = 1; y < 11; y++){     
        get_line(`${dir}/${files[x]}`, y, function(line){
            if (y == 5) {
                if (line != playerID) {
                    succ = false;
                } else {
                    lis +=`\n${newPlayerID}`; 
                }
            } else if (line == newPlayerID){
                lis +=`\n${playerID}`;
            } else if (line != 'Open') {
                lis += `\n${line}`;
            }
        });
    }
    if (succ) {
        fs.writeFile(`${dir}/${files[x]}`, lis, finished);
        embed = embed
            .setDescription(`Successfully changed leader.`);
        return;
    } else {
        embed = embed
            .setDescription(`You are not the Leader`);
        return;
    }
    
}
function get_line(filename, line_no, callback) {
    var data = fs.readFileSync(filename, 'utf8');
    var lines = data.split("\n");

    if(+line_no >= lines.length){
        callback(`Open`);
        return;
    }

    callback(lines[+line_no]);
}
function lineReading(filename, line_no, callback) {
    var data = fs.readFileSync(filename, 'utf8');
    var lines = data.split("\n");

    if(+line_no >= lines.length){
        callback(`@EENDOFLINE`);
        return;
    }

    callback(lines[+line_no]);
}

/*
            parts of speech

            noun        - entity
            pronoun     - already mentioned noun
            verb        - activity
            adverb      - inform about verb or adjective
            adjective   - decriptive
            prepostion  - shows relation of noun/pronoun to 
            conjunction - connect phrases, clauses and sentences
*/

function botResponse(message) {
    let chatArgs = message.content.split(" ");
    if (cleanCode(message.content.toLowerCase()) == `remrem` || cleanCode(message.content.toLowerCase()) == `remuremu`){
        message.channel.send(`${message.author.username} ${message.author.username}`);
        return;
    }

    if (message.author.bot && message.content == `Rem Rem, this person is talking to me.`) {
        return message.channel.send(`Sister Sister, I know just avoid that creepy person.`)
    }

    if (chatArgs.includes(`your`) && chatArgs.includes(`dad`)) {
        if (3 / chatArgs.length >= 0.5) {
            message.channel.send(`<@129095717535875073> is my daddy`);
            return;
        }
    }
    if (chatArgs.includes(`your`) && chatArgs.includes(`mom`)) {
        if (3 / chatArgs.length >= 0.5) {
            message.channel.send(`<@129095717535875073> is my daddy`);
            return;
        }
    }


    if (cleanCode(message.content.toLowerCase()) == `whosrem`){    
        return message.channel.send("Fuck You");
    }
    if (cleanCode(message.content.toLowerCase()).includes(`aretrapsgay`)){    
        return message.channel.send("Yes");
    }
    if (cleanCode(message.content.toLowerCase()) == `whatsthemeaningoflife`){
        return message.channel.send(`To Serve Me.`)
    }
    if (cleanCode(message.content.toLowerCase()) == `whatisthemeaningoflife`){
        return message.channel.send(`To Serve Me.`)
    }
    if (cleanCode(message.content.toLowerCase()).includes(`remsmash`)){
        if(message.author.id != 211376467114852352) {
            return message.channel.send(`You're not Darc`);
        }
        var rnd = Math.floor(Math.random() * 2);
        if (rnd == 0) {
            return message.channel.send(``,{
                file: "./images/smash.gif"
            });
        } else {
            return message.channel.send(``,{
                file: "./images/smasher.gif"
            });
        }
    }
    if (cleanCode(message.content.toLowerCase()).includes(`thedevilhimself`)){
        return message.channel.send(``,{
            file: "./images/emilia.png"
        });
    }
    if (cleanCode(message.content.toLowerCase()).includes(`subarulike`) || cleanCode(message.content.toLowerCase()).includes(`subarulove`) ){
        return message.channel.send(``,{
            file: "./images/subaru.jpg"
        });
    }
    if (cleanCode(message.content.toLowerCase()) == `iloveemilia`){    
        return message.channel.send(``,{
            file: "./images/love.gif"
        });
    }
    if (cleanCode(message.content.toLowerCase()) == `iloverem`){    
        return message.channel.send(``,{
            file: "./images/love2.gif"
        });
    }
    if (cleanCode(message.content.toLowerCase()) == `ilovefelix`){    
        return message.channel.send(``,{
            file: "./images/degen.png"
        });
    }
    if (cleanCode(message.content.toLowerCase()) == `ilovesubaru`){    
        return message.channel.send(``,{
            file: "./images/mine.png"
        });
    }
    if (cleanCode(message.content.toLowerCase()).includes(`makemecry`)){
        return message.channel.send(``,{
            file: "./images/sad.jpg"
        });
    }
    if (cleanCode(message.content.toLowerCase()).includes(`remtwister`)){
        return message.channel.send(``,{
            file: "./images/twister.jpg"
        });
    }
    if (cleanCode(message.content.toLowerCase()).includes(`heyrem`)){
        return message.channel.send(`Yeah?`);
    }
    if (cleanCode(message.content.toLowerCase()).includes(`your`) && cleanCode(message.content.toLowerCase()).includes(`opinion`) && cleanCode(message.content.toLowerCase()).includes(`sylvia`)){
        return message.channel.send(`Fuck Sylvia`);
    }


    if (cleanCode(message.content.toLowerCase()) == `ramram` || cleanCode(message.content.toLowerCase()) == `ramuramu`) return;
    if (cleanCode(message.content.toLowerCase()) == `iloveyouram` || cleanCode(message.content.toLowerCase()) == `iloveyouram`) return;

    if (message.content.includes(`Rem Rem, this person is talking to me.`)) {
        message.channel.send(`Sister Sister, I know just avoid that creepy person.`);
        return;
    }    
        
    if (message.author.bot) return;

    var request = app.textRequest(message.content, {
        sessionId: message.author.id
    });
    
    request.on('response', function(response) {
        try {
            message.channel.send(response.result.fulfillment.speech);
        } catch (err) {

        }
    });
    
    request.on('error', function(error) {
        console.log(error);
    });
    
    request.end();
}
